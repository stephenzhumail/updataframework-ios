//
//  Hello.h
//  Test
//
//  Created by StephenZhu on 15/4/20.
//  Copyright (c) 2015年 StephenZhu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Hello : NSObject
- (NSString*)Test;
@end
